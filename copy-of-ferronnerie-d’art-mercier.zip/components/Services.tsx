
import React from 'react';
import { SERVICES } from '../constants';
import { Link } from 'react-router-dom';

const Services: React.FC = () => {
  return (
    <section className="py-32 bg-suie relative">
      <div className="max-w-7xl mx-auto px-6">
        <div className="mb-24 text-center">
          <span className="text-gold text-[11px] font-bold uppercase tracking-[0.6em] mb-4 block">Notre Excellence Technique</span>
          <h2 className="text-parchment text-5xl md:text-8xl font-serif font-bold tracking-tight">Savoir-Faire</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {SERVICES.map((service) => (
            <div
              key={service.id}
              className="group relative glass-heritage p-12 min-h-[440px] flex flex-col justify-end transition-all duration-700 hover:bg-black/40 overflow-hidden border-gold/5 hover:border-gold/20"
            >
              {service.imageUrl && (
                <div className="absolute inset-0 z-0">
                  <img src={service.imageUrl} alt="" className="w-full h-full object-cover opacity-10 group-hover:opacity-40 transition-all duration-1000 grayscale group-hover:grayscale-0" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent"></div>
                </div>
              )}

              <div className="relative z-10">
                <div className="text-gold mb-10 w-16 h-16 border border-gold/20 flex items-center justify-center group-hover:bg-gold group-hover:text-black transition-all duration-500 rounded-full">
                  {service.icon}
                </div>
                <h3 className="text-3xl font-serif font-bold text-parchment mb-4 tracking-tight">{service.title}</h3>
                <p className="text-parchment/60 text-sm font-light leading-relaxed mb-10 group-hover:text-parchment transition-colors max-w-lg">
                  {service.description}
                </p>
                <Link to="/contact" className="inline-flex items-center gap-4 text-[10px] font-bold uppercase tracking-[0.4em] text-gold border-b border-gold/20 pb-2 group-hover:border-gold transition-all">
                  <span>Étudier un Projet</span>
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;
