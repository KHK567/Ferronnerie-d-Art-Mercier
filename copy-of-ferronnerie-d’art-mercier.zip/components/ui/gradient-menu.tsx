
import React from 'react';
import { Home, Hammer, Flame, Image as ImageIcon, MessageSquareQuote } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';

const menuItems = [
  { title: 'Accueil', path: '/', icon: <Home className="w-5 h-5" />, gradientFrom: '#C5A059', gradientTo: '#FFD700' }, // Gold/Brass
  { title: "L'Atelier", path: '/atelier', icon: <Hammer className="w-5 h-5" />, gradientFrom: '#4A4A4A', gradientTo: '#A9A9A9' }, // Steel/Iron
  { title: 'Savoir-Faire', path: '/services', icon: <Flame className="w-5 h-5" />, gradientFrom: '#D84315', gradientTo: '#FF5722' }, // Magma/Fire
  { title: 'Galerie', path: '/realisations', icon: <ImageIcon className="w-5 h-5" />, gradientFrom: '#8E2424', gradientTo: '#CD5C5C' }, // Rust/Copper
  { title: 'Avis', path: '/avis', icon: <MessageSquareQuote className="w-5 h-5" />, gradientFrom: '#F5F5F0', gradientTo: '#FFFFFF' } // Parchment/Light
];

export default function GradientMenu() {
  const location = useLocation();

  return (
    <div className="flex items-center">
      <ul className="flex gap-4">
        {menuItems.map(({ title, path, icon, gradientFrom, gradientTo }, idx) => (
          <li
            key={idx}
            // @ts-ignore
            style={{ '--gradient-from': gradientFrom, '--gradient-to': gradientTo }}
            className="relative w-[50px] h-[50px] bg-suie/80 border border-gold/10 shadow-[0_4px_10px_rgba(0,0,0,0.5)] rounded-full flex items-center justify-center transition-all duration-500 hover:w-[150px] hover:shadow-[0_0_25px_rgba(197,160,89,0.2)] group cursor-pointer"
          >
            <Link to={path} className="flex items-center justify-center w-full h-full relative z-20">
              {/* Gradient background on hover */}
              <span className="absolute inset-0 rounded-full bg-[linear-gradient(135deg,var(--gradient-from),var(--gradient-to))] opacity-0 transition-all duration-500 group-hover:opacity-100"></span>
              {/* Blur glow */}
              <span className="absolute top-[2px] inset-x-0 h-full rounded-full bg-[linear-gradient(135deg,var(--gradient-from),var(--gradient-to))] blur-[12px] opacity-0 -z-10 transition-all duration-500 group-hover:opacity-60"></span>

              {/* Icon */}
              <span className={`relative z-10 transition-all duration-500 group-hover:scale-0 delay-0 ${location.pathname === path ? 'text-gold' : 'text-parchment/40'}`}>
                {icon}
              </span>

              {/* Title */}
              <span className={`absolute text-black font-bold uppercase tracking-[0.2em] text-[10px] transition-all duration-500 scale-0 group-hover:scale-100 delay-100 whitespace-nowrap`}>
                {title}
              </span>
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
