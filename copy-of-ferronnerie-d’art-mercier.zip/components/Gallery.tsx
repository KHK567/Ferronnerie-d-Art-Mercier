
import React, { useState } from 'react';
import { PROJECTS } from '../constants';
import { Category } from '../types';
import { Link } from 'react-router-dom';

const Gallery: React.FC = () => {
  const [filter, setFilter] = useState<Category>('Tous');
  const categories: Category[] = [
    'Tous', 
    'Portails', 
    'Rampes d\'escalier', 
    'Marquises', 
    'Clôtures et grilles', 
    'Potences et puits', 
    'Portes d\'entrée', 
    'Galerie extérieure', 
    'Pergolas'
  ];
  const filteredProjects = PROJECTS.filter(p => filter === 'Tous' || p.category === filter);

  return (
    <section id="gallery" className="py-32 bg-black min-h-screen">
      <div className="max-w-7xl mx-auto px-6">
        
        <div className="flex flex-col lg:flex-row lg:items-end justify-between mb-32 gap-12">
          <div className="max-w-2xl">
            <span className="text-gold text-[11px] font-bold uppercase tracking-[0.6em] mb-6 block">Le Portfolio</span>
            <h2 className="text-parchment text-5xl md:text-8xl font-serif font-bold tracking-tight">La Galerie <br /><span className="italic font-normal text-gold">du Temps.</span></h2>
          </div>

          <div className="flex flex-wrap gap-4 lg:gap-6 justify-start lg:justify-end max-w-4xl">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setFilter(cat)}
                className={`text-[10px] md:text-[11px] font-bold uppercase tracking-[0.2em] transition-all duration-500 pb-2 border-b-2 ${
                  filter === cat
                    ? 'text-gold border-gold'
                    : 'text-parchment/30 border-transparent hover:text-parchment hover:border-parchment/30'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
          {filteredProjects.length > 0 ? (
            filteredProjects.map((project) => (
              <div
                key={project.id}
                className="group relative overflow-hidden bg-suie aspect-[4/5] transition-all duration-700"
              >
                <img
                  src={project.imageUrl}
                  alt={project.title}
                  className="w-full h-full object-cover grayscale brightness-50 transition-transform duration-[2s] ease-out group-hover:scale-105 group-hover:grayscale-0 group-hover:brightness-90"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-90"></div>
                
                <div className="absolute inset-0 p-12 flex flex-col justify-end">
                  <span className="text-gold text-[9px] uppercase tracking-[0.4em] font-bold mb-3 block opacity-0 group-hover:opacity-100 translate-y-4 group-hover:translate-y-0 transition-all duration-700">
                    {project.category}
                  </span>
                  <h3 className="text-parchment text-3xl font-serif font-bold mb-4 translate-y-4 group-hover:translate-y-0 transition-all duration-700 delay-100">
                    {project.title}
                  </h3>
                  <p className="text-parchment/60 text-sm italic font-light font-sans opacity-0 group-hover:opacity-100 transition-opacity duration-700 delay-200">
                    {project.description}
                  </p>
                </div>
              </div>
            ))
          ) : (
            <div className="col-span-1 md:col-span-3 text-center py-20 border border-white/5 bg-suie/30">
              <p className="text-parchment/40 italic font-serif text-xl">
                Aucune réalisation pour le moment dans cette catégorie.
              </p>
            </div>
          )}
        </div>

        <div className="mt-48 text-center border-t border-gold/10 pt-24">
            <p className="text-parchment/40 italic font-serif text-2xl mb-12">Chaque projet est une nouvelle page de notre histoire commune.</p>
            <Link 
                to="/contact"
                className="inline-block px-16 py-7 bg-gold text-black font-bold uppercase tracking-[0.5em] text-[11px] hover:bg-parchment transition-all duration-500 shadow-2xl"
            >
                Confier une Étude
            </Link>
        </div>
      </div>
    </section>
  );
};

export default Gallery;
