
import React from 'react';
import { PROCESS_STEPS } from '../constants';
import { Link } from 'react-router-dom';
import { ScrollText } from 'lucide-react';

const Processus: React.FC = () => {
  return (
    <section className="py-32 bg-black relative">
      <div className="max-w-7xl mx-auto px-6">
        <div className="max-w-4xl mb-32">
            <div className="flex items-center gap-4 mb-8 text-gold">
                <ScrollText className="w-5 h-5" />
                <span className="text-[11px] font-bold uppercase tracking-[0.5em]">Le Cycle de Création</span>
            </div>
            <h2 className="text-parchment text-5xl md:text-8xl font-serif font-bold tracking-tight mb-12">De la Vision <br /><span className="italic text-gold">à la Demeure.</span></h2>
            <p className="text-parchment/60 font-light font-sans text-xl leading-relaxed max-w-2xl italic">
                Un voyage entre la conception intellectuelle et la transformation physique de la matière par le feu.
            </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {PROCESS_STEPS.map((step) => (
            <div key={step.id} className="relative group p-12 glass-heritage transition-all duration-700 min-h-[420px] flex flex-col justify-between hover:bg-gold/5">
                <div className="text-gold/5 font-serif text-[10rem] font-bold absolute -top-8 -right-4 z-0 leading-none">0{step.id}</div>
                
                <div className="relative z-10">
                    <div className="text-gold mb-10 w-16 h-16 flex items-center justify-center group-hover:scale-110 transition-transform duration-500">
                        {step.icon}
                    </div>
                    <h4 className="text-parchment font-serif font-bold mb-6 text-2xl tracking-tight">{step.title}</h4>
                    <p className="text-parchment/50 text-sm leading-relaxed font-sans font-light group-hover:text-parchment/80 transition-colors italic">{step.description}</p>
                </div>

                <div className="relative z-10 pt-10">
                    <div className="h-px bg-gold/20 w-1/2 group-hover:w-full transition-all duration-700"></div>
                </div>
            </div>
            ))}
        </div>

        <div className="mt-40 p-16 border-hammered bg-suie relative overflow-hidden flex flex-col lg:flex-row items-center justify-between gap-16">
            <div className="max-w-2xl relative z-10">
                <h3 className="text-parchment text-3xl md:text-5xl font-serif font-bold mb-6">Prêt pour le premier geste ?</h3>
                <p className="text-parchment/60 font-light text-xl italic">Nous vous accueillons à l'atelier pour transformer votre idée en un ouvrage de caractère.</p>
            </div>
            <Link to="/contact" className="relative z-10 px-16 py-8 bg-gold text-black text-[11px] font-bold uppercase tracking-[0.5em] hover:bg-parchment transition-all shadow-2xl whitespace-nowrap">
                Prendre Rendez-vous
            </Link>
        </div>
      </div>
    </section>
  );
};

export default Processus;
