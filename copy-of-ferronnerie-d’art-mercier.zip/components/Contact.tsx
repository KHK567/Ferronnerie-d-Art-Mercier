
import React, { useState } from 'react';
import { Send, MapPin, Mail, Phone, MessageSquare, CheckCircle, Loader2 } from 'lucide-react';

const Contact: React.FC = () => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulation d'envoi réseau
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSuccess(true);
    }, 2000);
  };

  return (
    <section id="contact" className="py-32 bg-black relative">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-24">
          
          <div className="lg:col-span-5">
            <div className="inline-flex items-center gap-4 mb-8 text-gold">
               <MessageSquare className="w-5 h-5" />
               <span className="text-[11px] font-bold uppercase tracking-[0.4em]">Échange & Étude</span>
            </div>
            <h2 className="text-parchment text-5xl md:text-7xl font-serif font-bold tracking-tight mb-12">
              Donner vie à votre <br />
              <span className="italic text-gold">Vision.</span>
            </h2>
            <p className="text-parchment/60 mb-16 font-light text-xl leading-relaxed font-sans italic">
              Chaque projet commence par une écoute attentive. Partagez-nous vos envies, nous forgerons votre réalité.
            </p>

            <div className="space-y-10">
              <div className="flex items-start gap-6 group">
                <div className="w-12 h-12 border border-gold/20 flex items-center justify-center rounded-full shrink-0 group-hover:border-gold transition-colors">
                  <MapPin className="w-5 h-5 text-gold" />
                </div>
                <div>
                  <h4 className="text-parchment font-serif font-bold text-lg mb-1">L'Atelier</h4>
                  <p className="text-parchment/40 text-sm font-light">
                    Rue de l'Enclume, 39100 Dole<br />
                    Région Jura, France
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-6 group">
                <div className="w-12 h-12 border border-gold/20 flex items-center justify-center rounded-full shrink-0 group-hover:border-gold transition-colors">
                  <Mail className="w-5 h-5 text-gold" />
                </div>
                <div>
                  <h4 className="text-parchment font-serif font-bold text-lg mb-1">Courriel</h4>
                  <p className="text-parchment/40 text-sm font-light">
                    contact@mercier-ferronnerie.fr
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-6 group">
                <div className="w-12 h-12 border border-gold/20 flex items-center justify-center rounded-full shrink-0 group-hover:border-gold transition-colors">
                  <Phone className="w-5 h-5 text-gold" />
                </div>
                <div>
                  <h4 className="text-parchment font-serif font-bold text-lg mb-1">Téléphone</h4>
                  <p className="text-parchment/40 text-sm font-light">
                    +33 (0)3 84 XX XX XX
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-7">
            <div className="glass-heritage p-10 md:p-16 border-gold/10 relative min-h-[600px] flex items-center">
              {isSuccess ? (
                <div className="w-full flex flex-col items-center justify-center text-center animate-fade-in">
                  <div className="w-24 h-24 bg-gold/10 rounded-full flex items-center justify-center mb-8 border border-gold/40">
                    <CheckCircle className="w-12 h-12 text-gold" />
                  </div>
                  <h3 className="text-4xl font-serif font-bold text-parchment mb-6">Message Transmis</h3>
                  <p className="text-parchment/60 text-lg font-light max-w-md mx-auto mb-12 leading-relaxed">
                    Votre demande a bien été reçue par notre atelier. <br/>
                    Nous l'étudierons avec le plus grand soin et reviendrons vers vous sous 48 heures.
                  </p>
                  <button 
                    onClick={() => setIsSuccess(false)}
                    className="text-gold text-xs font-bold uppercase tracking-[0.2em] border-b border-gold/30 pb-2 hover:border-gold transition-all"
                  >
                    Envoyer une autre demande
                  </button>
                </div>
              ) : (
                <form className="space-y-12 w-full" onSubmit={handleSubmit}>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                      <div className="group relative">
                          <label className="text-[10px] uppercase tracking-[0.2em] font-bold text-gold/60 block mb-4">Votre nom</label>
                          <input 
                            required
                            type="text" 
                            className="w-full bg-transparent border-b border-gold/10 py-4 text-parchment focus:outline-none focus:border-gold transition-all font-light placeholder:text-parchment/10" 
                            placeholder="Jean Dupont" 
                          />
                      </div>
                      <div className="group relative">
                          <label className="text-[10px] uppercase tracking-[0.2em] font-bold text-gold/60 block mb-4">Adresse email</label>
                          <input 
                            required
                            type="email" 
                            className="w-full bg-transparent border-b border-gold/10 py-4 text-parchment focus:outline-none focus:border-gold transition-all font-light placeholder:text-parchment/10" 
                            placeholder="jean@exemple.fr" 
                          />
                      </div>
                  </div>
                  
                  <div className="group relative">
                      <label className="text-[10px] uppercase tracking-[0.2em] font-bold text-gold/60 block mb-4">Sujet de votre demande</label>
                      <input 
                        required
                        type="text" 
                        className="w-full bg-transparent border-b border-gold/10 py-4 text-parchment focus:outline-none focus:border-gold transition-all font-light placeholder:text-parchment/10" 
                        placeholder="Ex: Projet de garde-corps pour escalier" 
                      />
                  </div>

                  <div className="group relative">
                      <label className="text-[10px] uppercase tracking-[0.2em] font-bold text-gold/60 block mb-4">Détails du projet</label>
                      <textarea 
                        required
                        rows={5} 
                        className="w-full bg-transparent border-b border-gold/10 py-4 text-parchment focus:outline-none focus:border-gold transition-all font-light resize-none placeholder:text-parchment/10" 
                        placeholder="Décrivez ici votre projet, vos dimensions ou vos inspirations..."
                      ></textarea>
                  </div>

                  <button 
                    disabled={isSubmitting}
                    className="w-full bg-gold text-black py-6 text-[11px] font-bold uppercase tracking-[0.4em] hover:bg-parchment transition-all flex items-center justify-center gap-6 group shadow-xl disabled:opacity-70 disabled:cursor-not-allowed"
                  >
                    {isSubmitting ? (
                        <>
                            <span>Envoi en cours</span>
                            <Loader2 className="w-4 h-4 animate-spin" />
                        </>
                    ) : (
                        <>
                            <span>Envoyer ma demande</span>
                            <Send className="w-4 h-4 group-hover:translate-x-2 group-hover:-translate-y-1 transition-transform" />
                        </>
                    )}
                  </button>
                  
                  <p className="text-center text-parchment/20 text-[9px] uppercase tracking-widest italic">
                    Nous vous répondrons sous 48 heures ouvrées
                  </p>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
