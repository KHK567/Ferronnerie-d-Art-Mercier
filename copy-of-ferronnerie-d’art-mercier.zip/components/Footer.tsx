
import React from 'react';
import { Link } from 'react-router-dom';

const Footer: React.FC = () => {
  return (
    <footer className="bg-black border-t border-white/5 py-24">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-16 mb-24">
          <div className="md:col-span-2">
            <Link to="/" className="text-2xl font-serif font-bold tracking-tight mb-8 block text-white italic">Mercier Ferronnerie d'art</Link>
            <p className="text-metal-500 text-sm font-light max-w-sm leading-relaxed mb-8">
              Pionniers de la forge de caractère. Création d'ouvrages métalliques d'exception par la fusion du geste ancestral et de l'architecture moderne.
            </p>
          </div>
          <div>
            <h4 className="text-white text-[9px] font-bold uppercase tracking-widest mb-10 text-gold">Héritage</h4>
            <ul className="space-y-4">
                {[
                  { name: 'L\'Atelier', path: '/atelier' },
                  { name: 'Savoir-Faire', path: '/services' },
                  { name: 'Le Cycle', path: '/processus' },
                  { name: 'Galerie', path: '/realisations' }
                ].map(l => (
                    <li key={l.name}><Link to={l.path} className="text-metal-500 hover:text-gold text-xs transition-colors">{l.name}</Link></li>
                ))}
            </ul>
          </div>
          <div>
            <h4 className="text-white text-[9px] font-bold uppercase tracking-widest mb-10 text-gold">Transmission</h4>
            <p className="text-metal-500 text-xs mb-8 italic">Votre projet mérite l'éternité.</p>
            <Link to="/contact" className="text-gold text-[9px] font-bold uppercase tracking-widest border-b border-gold/30 pb-2 hover:border-gold transition-all">Initier le Trait</Link>
          </div>
        </div>
        <div className="flex flex-col md:flex-row justify-between items-center gap-8 pt-12 border-t border-white/5">
            <span className="text-metal-700 text-[8px] uppercase tracking-[0.5em]">© 2025 MERCIER_FORGE | MAÎTRE ARTISAN</span>
            <div className="flex gap-10">
                <span className="text-metal-700 text-[8px] uppercase tracking-[0.2em]">MENTIONS_LÉGALES</span>
                <span className="text-metal-700 text-[8px] uppercase tracking-[0.2em]">PATRIMOINE_VIVANT</span>
            </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
