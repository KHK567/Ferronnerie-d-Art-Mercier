
import React, { useState, useEffect } from 'react';
import { Menu, X, Flame } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import GradientMenu from './ui/gradient-menu';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Accueil', path: '/' },
    { name: 'L\'Atelier', path: '/atelier' },
    { name: 'Savoir-Faire', path: '/services' },
    { name: 'Galerie', path: '/realisations' },
    { name: 'Témoignages', path: '/avis' },
  ];

  return (
    <nav className={`fixed w-full z-50 transition-all duration-500 ${scrolled ? 'py-2 glass-heritage shadow-2xl shadow-black/50' : 'py-8 bg-transparent'}`}>
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex justify-between items-center">
          <Link to="/" className="flex items-center space-x-4 group">
            <div className="w-10 h-10 border border-gold/30 flex items-center justify-center rotate-45 group-hover:rotate-0 transition-all duration-700 bg-black overflow-hidden relative">
               <div className="absolute inset-0 bg-gradient-to-tr from-braise to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700"></div>
               <Flame className="w-5 h-5 -rotate-45 group-hover:rotate-0 text-gold group-hover:text-black relative z-10 transition-all duration-700" />
            </div>
            <div className="flex flex-col">
              <span className="font-serif text-2xl font-bold tracking-tight text-parchment leading-none group-hover:text-gold transition-colors">Mercier</span>
              <span className="text-[10px] text-gold/80 tracking-[0.3em] uppercase leading-none mt-1 font-sans">Ferronnerie d'Art</span>
            </div>
          </Link>

          {/* Integration of GradientMenu for Desktop */}
          <div className="hidden lg:block">
            <GradientMenu />
          </div>

          <div className="hidden lg:flex items-center">
            <Link
              to="/contact"
              className="group relative px-8 py-2.5 border border-gold/40 overflow-hidden transition-all"
            >
              <div className="absolute inset-0 w-0 bg-gold transition-all duration-[250ms] ease-out group-hover:w-full"></div>
              <span className="relative text-gold text-[10px] font-bold uppercase tracking-[0.3em] group-hover:text-black transition-colors">Contact</span>
            </Link>
          </div>

          <button onClick={() => setIsOpen(!isOpen)} className="lg:hidden text-parchment">
            {isOpen ? <X /> : <Menu />}
          </button>
        </div>
      </div>

      <div className={`lg:hidden fixed inset-0 bg-suie z-40 flex flex-col items-center justify-center gap-10 transition-all duration-500 ${isOpen ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-full pointer-events-none'}`}>
         {navLinks.map((link) => (
            <Link
              key={link.name}
              to={link.path}
              onClick={() => setIsOpen(false)}
              className="text-3xl font-serif text-parchment hover:text-gold transition-colors"
            >
              {link.name}
            </Link>
          ))}
          <Link to="/contact" onClick={() => setIsOpen(false)} className="text-gold border border-gold/40 px-10 py-4 uppercase tracking-[0.3em] text-xs font-bold">
            Demander une Étude
          </Link>
      </div>
    </nav>
  );
};

export default Navbar;
