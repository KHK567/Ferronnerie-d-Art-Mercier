
import React from 'react';
import { TESTIMONIALS } from '../constants';
import { Star, MessageSquareCode } from 'lucide-react';

const Testimonials: React.FC = () => {
  return (
    <section className="py-32 bg-black relative">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-32">
          <div className="flex justify-center mb-8">
            <div className="glass-heritage px-6 py-2 border-gold/20 flex items-center gap-3">
              <MessageSquareCode className="w-4 h-4 text-gold" />
              <span className="text-gold text-[10px] font-bold uppercase tracking-[0.8em]">Logs de Satisfaction</span>
            </div>
          </div>
          <h2 className="text-parchment text-5xl md:text-8xl font-serif font-bold tracking-tight uppercase">
            Vos <span className="text-transparent bg-clip-text bg-gradient-to-r from-gold to-white text-glow-warm italic font-normal">Avis.</span>
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {TESTIMONIALS.map((t) => (
            <div
              key={t.id}
              className="glass-heritage p-12 border-white/5 relative group hover:border-gold/30 transition-all duration-700"
            >
              <div className="flex mb-10 gap-1 text-gold">
                {[...Array(t.rating)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-current" />
                ))}
              </div>
              <p className="text-parchment/70 italic mb-12 leading-relaxed font-light text-xl font-serif">
                "{t.text}"
              </p>
              <div className="pt-10 border-t border-gold/10 flex items-center justify-between">
                <div>
                    <p className="text-parchment font-bold tracking-[0.2em] text-xs uppercase">{t.name}</p>
                    <p className="text-gold/50 text-[9px] uppercase tracking-[0.2em] mt-1 font-sans">{t.location}</p>
                </div>
                <div className="w-10 h-10 border border-gold/10 flex items-center justify-center opacity-30 group-hover:opacity-100 transition-opacity">
                    <span className="text-[8px] font-serif text-gold italic">Ref.</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
