
import React from 'react';
import { ChevronRight, Flame } from 'lucide-react';
import { Link } from 'react-router-dom';

const Hero: React.FC = () => {
  return (
    <section className="relative h-screen flex items-center justify-center overflow-hidden bg-black">
      {/* Background Forge Organique */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,_rgba(216,67,21,0.1)_0%,_transparent_70%)] animate-glow-warm" />
        <img
          src="https://res.cloudinary.com/dvwgxph9l/image/upload/celle_lae_l7r2qm.jpg"
          alt="L'antre du forgeron"
          className="w-full h-full object-cover opacity-30 mix-blend-screen scale-105 animate-smoke"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black via-transparent to-black" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-6 text-center">
        <div className="inline-flex items-center gap-4 px-6 py-2 border border-gold/20 bg-black/40 mb-10 animate-fade-in">
           <Flame className="w-4 h-4 text-braise" />
           <span className="text-[10px] uppercase tracking-[0.5em] text-gold font-medium">L'Excellence du Geste • Depuis 25 ans</span>
        </div>

        <h1 className="font-serif text-[clamp(2.5rem,8vw,10rem)] font-bold tracking-tight leading-[0.9] mb-10 text-parchment">
          Né de la <span className="italic font-normal text-gold text-glow-warm">Braise,</span><br />
          Façonné par la <span className="italic font-normal">Main.</span>
        </h1>
        
        <p className="text-parchment/70 text-lg md:text-2xl max-w-2xl mx-auto mb-16 font-light font-sans tracking-tight leading-relaxed">
          Quand le fer s'éveille sous l'enclume, l'ouvrage devient éternel. 
          Une alliance de savoir-faire ancestral et d'architecture contemporaine.
        </p>
        
        <div className="flex flex-col sm:flex-row gap-8 justify-center items-center">
          <Link
            to="/realisations"
            className="group relative px-14 py-6 bg-gold text-black text-[11px] font-bold uppercase tracking-[0.4em] transition-all duration-500 hover:bg-parchment hover:-translate-y-1 shadow-2xl"
          >
            Découvrir la Galerie
          </Link>
          <Link
            to="/contact"
            className="group flex items-center gap-4 text-parchment text-[11px] font-bold uppercase tracking-[0.4em] hover:text-gold transition-all duration-300"
          >
            <span>Confier un Projet</span>
            <ChevronRight className="w-4 h-4 group-hover:translate-x-2 transition-transform text-gold" />
          </Link>
        </div>
      </div>

      {/* Ornementation traditionnelle */}
      <div className="absolute left-10 bottom-20 flex flex-col items-center gap-6">
        <div className="text-[10px] font-serif italic text-gold/40 vertical-text tracking-[0.5em]">L'Art du Fer</div>
        <div className="w-px h-32 bg-gradient-to-t from-gold/30 to-transparent"></div>
      </div>
      <div className="absolute right-10 top-20 flex flex-col items-center gap-6">
        <div className="w-px h-32 bg-gradient-to-b from-gold/30 to-transparent"></div>
        <div className="text-[10px] font-serif italic text-gold/40 vertical-text tracking-[0.5em]">Dole • Jura</div>
      </div>
    </section>
  );
};

export default Hero;
