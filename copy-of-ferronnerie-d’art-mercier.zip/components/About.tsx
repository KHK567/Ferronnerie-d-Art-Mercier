
import React from 'react';
import { Hammer, Scroll } from 'lucide-react';

const About: React.FC = () => {
  return (
    <div className="bg-black pt-32">
      <section className="py-24 relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-6 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-24 items-center">
            
            <div className="lg:col-span-6 relative group">
              <div className="relative z-10 border-hammered overflow-hidden bg-suie p-2">
                <img
                  src="https://res.cloudinary.com/dvwgxph9l/image/upload/Generated_Image_January_03_2026_-_2_23AM_luwesf.jpg"
                  alt="Le Forgeron à l'œuvre"
                  className="w-full grayscale brightness-75 group-hover:brightness-100 group-hover:grayscale-0 transition-all duration-[3s] scale-100 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent opacity-60"></div>
              </div>
              
              {/* Ornement d'angle */}
              <div className="absolute -top-4 -left-4 w-20 h-20 border-t-2 border-l-2 border-gold/40"></div>
              <div className="absolute -bottom-4 -right-4 w-20 h-20 border-b-2 border-r-2 border-gold/40"></div>
            </div>

            <div className="lg:col-span-6">
              <div className="flex items-center gap-4 mb-8 text-gold">
                <Scroll className="w-5 h-5" />
                <span className="text-[11px] font-bold uppercase tracking-[0.4em]">Notre Histoire</span>
              </div>
              <h2 className="text-parchment text-5xl md:text-7xl font-serif font-bold tracking-tight mb-12">
                Dompter le Fer, <br />
                <span className="italic text-gold">Éveiller la Forme.</span>
              </h2>
              
              <div className="space-y-10 text-parchment/70 text-lg font-light font-sans leading-relaxed max-w-2xl">
                <p>
                  Au cœur du Jura, notre atelier perpétue un dialogue vieux de plusieurs millénaires entre l'homme et la matière. À Dole, la chaleur du foyer n'est pas seulement un outil, c'est le souffle qui permet à l'acier de s'exprimer.
                </p>
                <p>
                  Anthony Mercier, artisan d'art reconnu, guide chaque projet avec la rigueur du compagnon et l'œil de l'architecte. Nous ne fabriquons pas des grilles ou des escaliers ; nous forgeons des pièces de patrimoine qui traverseront les siècles.
                </p>
                <div className="pt-12 grid grid-cols-2 gap-12 border-t border-gold/10">
                    <div>
                        <div className="text-4xl font-serif font-bold text-gold mb-2">EPV</div>
                        <div className="text-[10px] uppercase tracking-[0.2em] text-parchment/40">Entreprise du Patrimoine Vivant</div>
                    </div>
                    <div>
                        <div className="text-4xl font-serif font-bold text-gold mb-2">1300°C</div>
                        <div className="text-[10px] uppercase tracking-[0.2em] text-parchment/40">Température du Cœur</div>
                    </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;
